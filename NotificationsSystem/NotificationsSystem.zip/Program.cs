﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NotificationsSystem.Interfaces;
using NotificationsSystem.Services;
using System;
using static NotificationsSystem.Services.Notifier;

var host = Host.CreateDefaultBuilder(args)
    .ConfigureServices(services =>
    {
        services.AddTransient<INotifier, EmailService>();
        services.AddTransient<INotifier, SMSService>();
        services.AddTransient<INotifier, PushNotificationService>();
    })
    .Build();

Notifier emailNotifier = new Notifier(new EmailService());

NotifierDelegate notifierDelegate = new NotifierDelegate(emailNotifier.Send);

Notifier smsNotifier = new Notifier(new SMSService());

notifierDelegate += smsNotifier.Send;

Notifier pushNotificationNotifier = new Notifier(new PushNotificationService());

notifierDelegate += pushNotificationNotifier.Send;

notifierDelegate("Hello doha");

bool isContinue = true;
bool isValid = true;

while (isContinue)
{
    Console.WriteLine("Which method would you remove (1- SMS 2- Email 3- PushNotification) ?");
    Console.WriteLine("Write the number of the option : ");
    string option = Console.ReadLine();

    switch (option)
    {
        case "1":
            notifierDelegate -= smsNotifier.Send;
            break;
        case "2":
            notifierDelegate -= emailNotifier.Send;
            break;
        case "3":
            notifierDelegate -= pushNotificationNotifier.Send;
            break;
        default:
            Console.WriteLine("Invalid Option !");
            isValid = false;
            break;
    }

    if (isValid)
    {
        notifierDelegate("Hello doha");
        break;
    }
    else
    {
        continue;
    }

}



