﻿using NotificationsSystem.Interfaces;

namespace NotificationsSystem.Services
{
    internal class Notifier
    {
        private readonly INotifier _notifier;

        public Notifier(INotifier notifier)
        {
            _notifier = notifier;
        }

        public void Send(string message)
        {
            _notifier.Send(message);
        }

        public delegate void NotifierDelegate(string message);



    }
}
