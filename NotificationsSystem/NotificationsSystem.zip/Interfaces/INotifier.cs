﻿namespace NotificationsSystem.Interfaces
{
    internal interface INotifier
    {
        void Send(string message);
    }
}
